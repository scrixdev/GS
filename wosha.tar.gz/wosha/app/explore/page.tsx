import { Search, TrendingUp, Users, Hash } from 'lucide-react';
import { mockUsers, mockPosts } from '@/lib/mockData';

export default function ExplorePage() {
  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-black mb-6" style={{ fontFamily: 'Orbitron,monospace', background: 'linear-gradient(135deg,#06b6d4,#3b82f6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>EXPLORE</h1>
      <div className="relative mb-8">
        <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2" style={{ color: '#555577' }} />
        <input placeholder="Search WOSHA..." className="w-full pl-12 pr-4 py-4 rounded-2xl text-sm outline-none" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.2)', color: '#c0c0dd', fontSize: 15 }} />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-5 rounded-2xl" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.1)' }}>
          <div className="flex items-center gap-2 mb-4"><TrendingUp size={16} style={{ color: '#a855f7' }} /><h3 className="font-bold text-white">Trending</h3></div>
          {['#WOSHA', '#Gaming', '#Manhwa', '#DigitalArt', '#Esports'].map((tag, i) => (
            <div key={tag} className="flex items-center justify-between py-3 cursor-pointer hover:bg-white/3 rounded-xl px-2 transition-colors" style={{ borderBottom: i < 4 ? '1px solid rgba(168,85,247,0.06)' : 'none' }}>
              <div><span className="text-xs" style={{ color: '#333355' }}>#{i+1}</span><p className="font-semibold text-sm" style={{ color: '#818cf8' }}>{tag}</p></div>
              <span className="text-xs" style={{ color: '#333355' }}>{Math.floor(Math.random()*90+10)}K posts</span>
            </div>
          ))}
        </div>
        <div className="p-5 rounded-2xl" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.1)' }}>
          <div className="flex items-center gap-2 mb-4"><Users size={16} style={{ color: '#a855f7' }} /><h3 className="font-bold text-white">Top Creators</h3></div>
          {mockUsers.map(u => (
            <div key={u.id} className="flex items-center gap-3 py-3" style={{ borderBottom: '1px solid rgba(168,85,247,0.06)' }}>
              <div className="w-10 h-10 rounded-full overflow-hidden" style={{ border: '2px solid rgba(168,85,247,0.3)' }}><img src={u.avatar} alt="" className="w-full h-full object-cover" /></div>
              <div className="flex-1"><p className="font-semibold text-sm text-white">{u.username}</p><p className="text-xs" style={{ color: '#555577' }}>{(u.followers/1000).toFixed(1)}K followers</p></div>
              <button className="px-3 py-1.5 rounded-full text-xs font-semibold" style={{ background: 'linear-gradient(135deg,#a855f7,#3b82f6)', color: 'white' }}>Follow</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
