'use client';
import { CheckCircle2, Edit, MessageCircle, Zap } from 'lucide-react';
import { mockUsers, mockPosts } from '@/lib/mockData';
import PostCard from '@/components/feed/PostCard';

const user = mockUsers[0];
const tabs = ['Posts', 'Videos', 'Media', 'Communities', 'Gaming'];

export default function ProfilePage() {
  const fmt = (n: number) => n >= 1000 ? (n/1000).toFixed(1) + 'K' : n.toString();
  const xpPct = (user.xp % 10000) / 100;
  return (
    <div className="max-w-3xl mx-auto pb-12">
      <div className="relative h-48 rounded-b-3xl overflow-hidden">
        <div style={{ background: 'linear-gradient(135deg, #1a0033, #000d1a, #0d0033)', width: '100%', height: '100%', position: 'relative' }}>
          <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(ellipse at 30% 50%, rgba(168,85,247,0.3) 0%, transparent 60%)' }} />
          <p className="absolute inset-0 flex items-center justify-center" style={{ fontFamily: 'Orbitron,monospace', fontSize: 60, fontWeight: 900, color: 'rgba(168,85,247,0.15)', letterSpacing: 8 }}>WOSHA</p>
        </div>
      </div>
      <div className="px-6">
        <div className="flex items-end justify-between -mt-14 mb-4">
          <div className="relative">
            <div className="w-28 h-28 rounded-2xl overflow-hidden" style={{ border: '4px solid #030308', boxShadow: '0 0 20px rgba(168,85,247,0.5)', background: '#1a0033' }}>
              <img src={user.avatar} alt={user.username} className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-1 -right-1 px-2 py-0.5 rounded-lg text-xs font-bold" style={{ background: 'linear-gradient(135deg,#a855f7,#3b82f6)', color: 'white' }}>Lv.{user.level}</div>
          </div>
          <div className="flex gap-2 mb-2">
            <button className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold" style={{ background: 'rgba(168,85,247,0.2)', border: '1px solid rgba(168,85,247,0.3)', color: '#d8b4fe' }}><MessageCircle size={14} /> Message</button>
            <button className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold" style={{ background: 'linear-gradient(135deg,#a855f7,#3b82f6)', color: 'white' }}><Edit size={14} /> Edit Profile</button>
          </div>
        </div>
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-1">
            <h1 className="text-2xl font-black text-white">{user.username}</h1>
            {user.verified && <CheckCircle2 size={18} style={{ color: '#3b82f6' }} />}
            <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(168,85,247,0.2)', color: '#a855f7' }}>⚡ OG</span>
          </div>
          <p className="text-sm" style={{ color: '#6644aa' }}>@{user.handle}</p>
          <p className="text-sm mt-2" style={{ color: '#aaaacc' }}>{user.bio}</p>
        </div>
        <div className="grid grid-cols-4 gap-3 mb-5">
          {[{l:'Followers',v:fmt(user.followers)},{l:'Following',v:fmt(user.following)},{l:'Posts',v:'247'},{l:'XP',v:(user.xp/1000).toFixed(1)+'K'}].map(s => (
            <div key={s.l} className="text-center p-3 rounded-xl" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.1)' }}>
              <p className="text-lg font-black text-white">{s.v}</p>
              <p className="text-xs" style={{ color: '#555577' }}>{s.l}</p>
            </div>
          ))}
        </div>
        <div className="mb-5 p-4 rounded-xl" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.1)' }}>
          <div className="flex justify-between mb-2">
            <div className="flex items-center gap-2"><Zap size={14} style={{ color: '#a855f7' }} /><span className="text-sm font-semibold text-white">Level {user.level}</span></div>
            <span className="text-xs" style={{ color: '#555577' }}>{(user.xp % 10000).toLocaleString()} / 10,000 XP</span>
          </div>
          <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(168,85,247,0.1)' }}>
            <div style={{ width: `${xpPct}%`, height: '100%', background: 'linear-gradient(90deg,#a855f7,#3b82f6)', borderRadius: 9999 }} />
          </div>
        </div>
        <div className="flex gap-1 mb-6 p-1 rounded-xl" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.1)' }}>
          {tabs.map((tab, i) => (
            <button key={tab} className="flex-1 py-2 rounded-lg text-sm font-semibold transition-all"
              style={i===0 ? { background: 'linear-gradient(135deg,rgba(168,85,247,0.3),rgba(59,130,246,0.3))', color: '#d8b4fe', border: '1px solid rgba(168,85,247,0.2)' } : { color: '#555577' }}>{tab}</button>
          ))}
        </div>
        <div className="space-y-4">{mockPosts.map(p => <PostCard key={p.id} post={p} />)}</div>
      </div>
    </div>
  );
}
