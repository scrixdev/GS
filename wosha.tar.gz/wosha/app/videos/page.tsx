'use client';
import { useState } from 'react';
import { Heart, MessageCircle, Share2, Bookmark, Music2, Plus, CheckCircle2 } from 'lucide-react';

const mockVideos = [
  { id: '1', creator: 'AkiraStorm', handle: 'akirastorm', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=akira', verified: true, caption: 'New digital art technique unlocked 🎨 This took 3 months to master #DigitalArt #WOSHA #Tutorial', music: 'Neon Nights — SynthWave X', likes: 48200, comments: 3400, bg: 'https://picsum.photos/seed/vid1/400/700' },
  { id: '2', creator: 'NeonSakura', handle: 'neonsakura', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sakura', verified: true, caption: 'Chapter 47 spoiler! 👀 You won\'t believe what happens next... #Manhwa #WOSHA #Original', music: 'Cherry Blossom Dreams — Lo-fi Soul', likes: 124000, comments: 18900, bg: 'https://picsum.photos/seed/vid2/400/700' },
  { id: '3', creator: 'CyberWolf', handle: 'cyberwolf', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=wolf', verified: false, caption: 'Final boss run in under 2 minutes 🏆 WORLD RECORD?! #Gaming #Speedrun #Esports', music: 'Boss Battle Mode — Cyber Orchestra', likes: 89000, comments: 12400, bg: 'https://picsum.photos/seed/vid3/400/700' },
];

export default function VideosPage() {
  const [current, setCurrent] = useState(0);
  const [liked, setLiked] = useState<Record<string, boolean>>({});
  const [saved, setSaved] = useState<Record<string, boolean>>({});
  const video = mockVideos[current];

  const fmt = (n: number) => n >= 1000 ? (n/1000).toFixed(0) + 'K' : n.toString();

  return (
    <div className="flex h-screen items-center justify-center" style={{ background: '#000' }}>
      {/* Video Container */}
      <div className="relative w-full max-w-sm h-screen overflow-hidden" style={{ maxHeight: '100vh' }}>
        {/* Background */}
        <div className="absolute inset-0">
          <img src={video.bg} alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.2) 40%, rgba(0,0,0,0.1) 60%, rgba(0,0,0,0.6) 100%)' }} />
        </div>

        {/* Play indicator */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-16 h-16 rounded-full flex items-center justify-center opacity-0" style={{ background: 'rgba(255,255,255,0.2)', backdropFilter: 'blur(10px)' }}>
            <div className="w-0 h-0 border-t-8 border-b-8 border-l-16" style={{ borderTopColor: 'transparent', borderBottomColor: 'transparent', borderLeftColor: 'white', marginLeft: 4 }} />
          </div>
        </div>

        {/* Content overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-5 pb-8">
          <div className="flex items-end gap-3">
            {/* Left: creator info + caption */}
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-10 h-10 rounded-full overflow-hidden" style={{ border: '2px solid white' }}>
                  <img src={video.avatar} alt="" className="w-full h-full object-cover" />
                </div>
                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-bold text-white text-sm">@{video.handle}</span>
                    {video.verified && <CheckCircle2 size={13} style={{ color: '#3b82f6' }} />}
                  </div>
                </div>
                <button className="px-3 py-1 rounded-full text-xs font-bold" style={{ border: '1.5px solid white', color: 'white' }}>Follow</button>
              </div>
              <p className="text-white text-sm leading-relaxed mb-3 line-clamp-3">{video.caption}</p>
              <div className="flex items-center gap-2">
                <Music2 size={12} className="text-white" />
                <p className="text-white text-xs">{video.music}</p>
              </div>
            </div>

            {/* Right: action buttons */}
            <div className="flex flex-col gap-5 items-center">
              <button onClick={() => setLiked(l => ({ ...l, [video.id]: !l[video.id] }))} className="flex flex-col items-center gap-1">
                <div className="w-11 h-11 rounded-full flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(10px)' }}>
                  <Heart size={20} className={liked[video.id] ? 'fill-red-500 text-red-500' : 'text-white'} />
                </div>
                <span className="text-white text-xs font-semibold">{fmt(video.likes + (liked[video.id] ? 1 : 0))}</span>
              </button>
              <button className="flex flex-col items-center gap-1">
                <div className="w-11 h-11 rounded-full flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(10px)' }}>
                  <MessageCircle size={20} className="text-white" />
                </div>
                <span className="text-white text-xs font-semibold">{fmt(video.comments)}</span>
              </button>
              <button onClick={() => setSaved(s => ({ ...s, [video.id]: !s[video.id] }))} className="flex flex-col items-center gap-1">
                <div className="w-11 h-11 rounded-full flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(10px)' }}>
                  <Bookmark size={20} className={saved[video.id] ? 'fill-purple-400 text-purple-400' : 'text-white'} />
                </div>
                <span className="text-white text-xs font-semibold">Save</span>
              </button>
              <button className="flex flex-col items-center gap-1">
                <div className="w-11 h-11 rounded-full flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.15)', backdropFilter: 'blur(10px)' }}>
                  <Share2 size={20} className="text-white" />
                </div>
                <span className="text-white text-xs font-semibold">Share</span>
              </button>
            </div>
          </div>
        </div>

        {/* Navigation dots */}
        <div className="absolute right-2 top-1/2 -translate-y-1/2 flex flex-col gap-2">
          {mockVideos.map((_, i) => (
            <button key={i} onClick={() => setCurrent(i)} className="w-1 rounded-full transition-all" style={{ height: i === current ? 24 : 8, background: i === current ? '#a855f7' : 'rgba(255,255,255,0.3)' }} />
          ))}
        </div>

        {/* Upload button */}
        <button className="absolute top-14 right-4 w-10 h-10 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #a855f7, #3b82f6)', boxShadow: '0 0 15px rgba(168,85,247,0.5)' }}>
          <Plus size={20} className="text-white" />
        </button>
      </div>

      {/* Side navigation for desktop */}
      <div className="hidden lg:flex flex-col gap-3 ml-4">
        {mockVideos.map((v, i) => (
          <button key={v.id} onClick={() => setCurrent(i)} className="w-16 h-24 rounded-xl overflow-hidden transition-all" style={{ border: i === current ? '2px solid #a855f7' : '2px solid transparent', opacity: i === current ? 1 : 0.5 }}>
            <img src={v.bg} alt="" className="w-full h-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
}
