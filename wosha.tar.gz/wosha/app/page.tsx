import PostComposer from '@/components/feed/PostComposer';
import PostCard from '@/components/feed/PostCard';
import { mockPosts, mockUsers } from '@/lib/mockData';
import { TrendingUp, Users, CheckCircle2 } from 'lucide-react';

const trending = ['#WOSHA', '#DigitalArt', '#Esports', '#Manhwa', '#NFT', '#Gaming'];

export default function FeedPage() {
  return (
    <div className="flex gap-6 p-6 max-w-7xl mx-auto">
      {/* Main Feed */}
      <div className="flex-1 space-y-4 min-w-0">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-black" style={{ fontFamily: 'Orbitron, monospace', background: 'linear-gradient(135deg, #a855f7, #3b82f6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
            FOR YOU
          </h1>
          <div className="flex gap-2">
            {['For You', 'Following', 'Trending'].map(tab => (
              <button key={tab} className="px-4 py-1.5 rounded-full text-sm font-medium transition-all" style={tab === 'For You' ? { background: 'rgba(168,85,247,0.2)', color: '#d8b4fe', border: '1px solid rgba(168,85,247,0.3)' } : { color: '#555577', border: '1px solid transparent' }}>
                {tab}
              </button>
            ))}
          </div>
        </div>
        <PostComposer />
        {mockPosts.map(post => <PostCard key={post.id} post={post} />)}
      </div>

      {/* Right Sidebar */}
      <div className="w-72 flex-shrink-0 space-y-4">
        {/* Trending */}
        <div className="rounded-2xl p-5" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.1)' }}>
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp size={16} style={{ color: '#a855f7' }} />
            <h3 className="font-bold text-sm text-white">Trending on WOSHA</h3>
          </div>
          <div className="space-y-2">
            {trending.map((tag, i) => (
              <div key={tag} className="flex items-center justify-between py-2 px-3 rounded-xl hover:bg-white/5 cursor-pointer transition-colors group">
                <div>
                  <span className="text-xs" style={{ color: '#333355' }}>#{i + 1} Trending</span>
                  <p className="text-sm font-semibold" style={{ color: '#818cf8' }}>{tag}</p>
                </div>
                <span className="text-xs" style={{ color: '#333355' }}>{Math.floor(Math.random() * 50 + 5)}K</span>
              </div>
            ))}
          </div>
        </div>

        {/* Suggested Users */}
        <div className="rounded-2xl p-5" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.1)' }}>
          <div className="flex items-center gap-2 mb-4">
            <Users size={16} style={{ color: '#a855f7' }} />
            <h3 className="font-bold text-sm text-white">Suggested Creators</h3>
          </div>
          <div className="space-y-3">
            {mockUsers.map(user => (
              <div key={user.id} className="flex items-center gap-3">
                <div className="relative flex-shrink-0">
                  <div className="w-9 h-9 rounded-full overflow-hidden" style={{ border: '2px solid rgba(168,85,247,0.3)' }}>
                    <img src={user.avatar} alt={user.username} className="w-full h-full object-cover" />
                  </div>
                  {user.isOnline && <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2" style={{ background: '#22c55e', borderColor: '#030308' }} />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="text-sm font-semibold text-white truncate">{user.username}</span>
                    {user.verified && <CheckCircle2 size={11} style={{ color: '#3b82f6' }} />}
                  </div>
                  <span className="text-xs" style={{ color: '#555577' }}>{(user.followers / 1000).toFixed(1)}K followers</span>
                </div>
                <button className="text-xs px-3 py-1.5 rounded-full font-semibold transition-all hover:opacity-80"
                  style={{ background: 'linear-gradient(135deg, #a855f7, #3b82f6)', color: 'white' }}>
                  Follow
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
