import { mockMarketItems } from '@/lib/mockData';
import { ShoppingBag, Wallet, Star } from 'lucide-react';

const rarityColors: Record<string, string> = {
  common: '#6b7280', rare: '#3b82f6', epic: '#a855f7', legendary: '#f59e0b'
};

export default function MarketplacePage() {
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-black" style={{ fontFamily: 'Orbitron,monospace', background: 'linear-gradient(135deg,#a855f7,#f59e0b)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>MARKETPLACE</h1>
        <div className="flex items-center gap-2 px-4 py-2.5 rounded-xl" style={{ background: 'rgba(245,158,11,0.15)', border: '1px solid rgba(245,158,11,0.3)' }}>
          <Wallet size={16} style={{ color: '#f59e0b' }} />
          <span className="font-bold text-sm" style={{ color: '#fbbf24' }}>2,450 WOSHA</span>
        </div>
      </div>

      <div className="flex gap-2 mb-6 flex-wrap">
        {['All', 'Avatars', 'Themes', 'Badges', 'Stickers', 'Skins'].map((cat, i) => (
          <button key={cat} className="px-4 py-2 rounded-full text-sm font-medium transition-all"
            style={i===0 ? { background: 'rgba(168,85,247,0.2)', color: '#d8b4fe', border: '1px solid rgba(168,85,247,0.3)' } : { color: '#555577', border: '1px solid rgba(255,255,255,0.05)' }}>
            {cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {mockMarketItems.map(item => (
          <div key={item.id} className="rounded-2xl overflow-hidden card-hover cursor-pointer" style={{ background: 'rgba(13,13,26,0.8)', border: `1px solid ${rarityColors[item.rarity]}33` }}>
            <div className="h-36 flex items-center justify-center relative" style={{ background: 'linear-gradient(135deg,rgba(13,13,26,1),rgba(26,0,51,0.8))' }}>
              <img src={item.image} alt={item.name} className="w-20 h-20 object-contain" />
              <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full text-xs font-bold capitalize" style={{ background: `${rarityColors[item.rarity]}22`, color: rarityColors[item.rarity], border: `1px solid ${rarityColors[item.rarity]}44` }}>
                {item.rarity}
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-semibold text-white text-sm mb-3">{item.name}</h3>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Star size={12} style={{ color: '#f59e0b', fill: '#f59e0b' }} />
                  <span className="text-sm font-bold" style={{ color: '#fbbf24' }}>{item.price}</span>
                </div>
                <button className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all hover:opacity-80" style={{ background: 'linear-gradient(135deg,#a855f7,#3b82f6)', color: 'white' }}>Buy</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
