import { mockUsers } from '@/lib/mockData';
import { Trophy, Zap, Shield, Swords, Users, Star } from 'lucide-react';

const achievements = [
  { name: 'First Blood', icon: '⚔️', desc: 'Win your first tournament', earned: true },
  { name: 'Legend', icon: '🏆', desc: 'Reach Level 50', earned: true },
  { name: 'Creator', icon: '🎨', desc: 'Post 100 pieces', earned: true },
  { name: 'Social King', icon: '👑', desc: '10K followers', earned: false },
];

const leaderboard = [
  { rank: 1, user: mockUsers[0], score: 98400 },
  { rank: 2, user: mockUsers[1], score: 67800 },
  { rank: 3, user: mockUsers[2], score: 45200 },
];

export default function GamingPage() {
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-3xl font-black mb-8" style={{ fontFamily: 'Orbitron,monospace', background: 'linear-gradient(135deg,#22c55e,#3b82f6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>GAMING HUB</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Gamer Card */}
        <div className="lg:col-span-1 space-y-4">
          <div className="p-5 rounded-2xl" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.15)' }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-14 h-14 rounded-xl overflow-hidden" style={{ border: '2px solid rgba(168,85,247,0.4)' }}>
                <img src={mockUsers[0].avatar} alt="" className="w-full h-full object-cover" />
              </div>
              <div>
                <p className="font-bold text-white">{mockUsers[0].username}</p>
                <div className="flex items-center gap-1">
                  <Zap size={12} style={{ color: '#a855f7' }} />
                  <span className="text-xs" style={{ color: '#a855f7' }}>Level {mockUsers[0].level}</span>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {[{l:'Wins',v:'247'},{l:'Tournaments',v:'18'},{l:'Clan Rank',v:'#3'},{l:'Kill Streak',v:'12'}].map(s => (
                <div key={s.l} className="p-3 rounded-xl text-center" style={{ background: 'rgba(168,85,247,0.08)', border: '1px solid rgba(168,85,247,0.1)' }}>
                  <p className="font-black text-white">{s.v}</p>
                  <p className="text-xs" style={{ color: '#555577' }}>{s.l}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Achievements */}
          <div className="p-5 rounded-2xl" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.15)' }}>
            <div className="flex items-center gap-2 mb-4">
              <Trophy size={16} style={{ color: '#f59e0b' }} />
              <h3 className="font-bold text-white">Achievements</h3>
            </div>
            <div className="space-y-2">
              {achievements.map(a => (
                <div key={a.name} className="flex items-center gap-3 p-2 rounded-xl" style={{ background: a.earned ? 'rgba(168,85,247,0.08)' : 'transparent', opacity: a.earned ? 1 : 0.4 }}>
                  <span className="text-xl">{a.icon}</span>
                  <div>
                    <p className="text-sm font-semibold text-white">{a.name}</p>
                    <p className="text-xs" style={{ color: '#555577' }}>{a.desc}</p>
                  </div>
                  {a.earned && <Star size={12} className="ml-auto" style={{ color: '#f59e0b', fill: '#f59e0b' }} />}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Leaderboard + Tournaments */}
        <div className="lg:col-span-2 space-y-4">
          <div className="p-5 rounded-2xl" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.15)' }}>
            <div className="flex items-center gap-2 mb-5">
              <Trophy size={16} style={{ color: '#f59e0b' }} />
              <h3 className="font-bold text-white">Global Leaderboard</h3>
            </div>
            <div className="space-y-3">
              {leaderboard.map(e => (
                <div key={e.rank} className="flex items-center gap-4 p-3 rounded-xl" style={{ background: e.rank===1 ? 'rgba(245,158,11,0.1)' : 'rgba(168,85,247,0.05)', border: e.rank===1 ? '1px solid rgba(245,158,11,0.2)' : '1px solid transparent' }}>
                  <span className="text-xl font-black w-8 text-center" style={{ color: e.rank===1 ? '#f59e0b' : e.rank===2 ? '#9ca3af' : '#92400e' }}>#{e.rank}</span>
                  <div className="w-10 h-10 rounded-full overflow-hidden" style={{ border: '2px solid rgba(168,85,247,0.3)' }}>
                    <img src={e.user.avatar} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-white text-sm">{e.user.username}</p>
                    <p className="text-xs" style={{ color: '#555577' }}>Level {e.user.level}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-black text-sm" style={{ color: '#a855f7' }}>{e.score.toLocaleString()}</p>
                    <p className="text-xs" style={{ color: '#555577' }}>XP</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Upcoming Tournaments */}
          <div className="p-5 rounded-2xl" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.15)' }}>
            <div className="flex items-center gap-2 mb-4">
              <Swords size={16} style={{ color: '#ef4444' }} />
              <h3 className="font-bold text-white">Upcoming Tournaments</h3>
            </div>
            {[{ name: 'WOSHA Grand Prix', prize: '10,000 WOSHA', players: 128, date: 'Jun 1' }, { name: 'Season Finals', prize: '5,000 WOSHA', players: 64, date: 'Jun 8' }].map(t => (
              <div key={t.name} className="flex items-center justify-between p-4 rounded-xl mb-3 last:mb-0" style={{ background: 'rgba(239,68,68,0.05)', border: '1px solid rgba(239,68,68,0.15)' }}>
                <div>
                  <p className="font-bold text-white">{t.name}</p>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="text-xs" style={{ color: '#f59e0b' }}>🏆 {t.prize}</span>
                    <span className="text-xs" style={{ color: '#555577' }}><Users size={10} className="inline mr-1" />{t.players} players</span>
                    <span className="text-xs" style={{ color: '#555577' }}>{t.date}</span>
                  </div>
                </div>
                <button className="px-4 py-2 rounded-xl text-sm font-semibold" style={{ background: 'rgba(239,68,68,0.2)', color: '#f87171', border: '1px solid rgba(239,68,68,0.3)' }}>Join</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
