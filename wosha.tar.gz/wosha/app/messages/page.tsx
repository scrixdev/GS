'use client';
import { useState } from 'react';
import { Search, Pin, Phone, Video, MoreHorizontal, Send, Smile, Image, Mic, CheckCircle2 } from 'lucide-react';
import { mockConversations, mockUsers } from '@/lib/mockData';

const messages = [
  { id: '1', senderId: '2', content: 'Hey! Did you see my new collection drop?', time: '2:30 PM', read: true },
  { id: '2', senderId: '1', content: 'Not yet! Send me the link 🔥', time: '2:31 PM', read: true },
  { id: '3', senderId: '2', content: 'Check it out on WOSHA, it\'s fire 🎨', time: '2:32 PM', read: true },
  { id: '4', senderId: '1', content: 'WOW this is insane!! Copping the dragon avatar for sure', time: '2:35 PM', read: false },
];

export default function MessagesPage() {
  const [selected, setSelected] = useState(mockConversations[0]);
  const [msg, setMsg] = useState('');
  const me = mockUsers[0];

  return (
    <div className="flex h-screen" style={{ paddingTop: 0 }}>
      {/* Conversations List */}
      <div className="w-80 flex-shrink-0 flex flex-col" style={{ background: 'rgba(8,8,18,0.95)', borderRight: '1px solid rgba(168,85,247,0.1)', height: '100vh' }}>
        <div className="p-5">
          <h2 className="text-xl font-black mb-4 text-white" style={{ fontFamily: 'Orbitron, monospace' }}>MESSAGES</h2>
          <div className="relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2" style={{ color: '#555577' }} />
            <input placeholder="Search conversations..." className="w-full pl-9 pr-4 py-2.5 rounded-xl text-sm bg-transparent outline-none" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.15)', color: '#c0c0dd' }} />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto px-3 space-y-1">
          {mockConversations.map(conv => {
            const other = conv.isGroup ? null : conv.participants.find(p => p.id !== me.id);
            const name = conv.isGroup ? conv.groupName : other?.username;
            const avatar = conv.isGroup ? 'https://api.dicebear.com/7.x/shapes/svg?seed=group' : other?.avatar;
            const active = selected.id === conv.id;
            return (
              <button key={conv.id} onClick={() => setSelected(conv)} className="w-full flex items-center gap-3 p-3 rounded-xl transition-all text-left"
                style={{ background: active ? 'rgba(168,85,247,0.12)' : 'transparent', border: active ? '1px solid rgba(168,85,247,0.2)' : '1px solid transparent' }}>
                <div className="relative flex-shrink-0">
                  <div className="w-11 h-11 rounded-full overflow-hidden" style={{ border: '2px solid rgba(168,85,247,0.3)' }}>
                    <img src={avatar} alt={name || ''} className="w-full h-full object-cover" />
                  </div>
                  {other?.isOnline && <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2" style={{ background: '#22c55e', borderColor: '#030308' }} />}
                  {conv.pinned && <Pin size={8} className="absolute -top-0.5 -right-0.5 text-purple-400" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between">
                    <span className="text-sm font-semibold text-white truncate">{name}</span>
                    <span className="text-xs flex-shrink-0 ml-1" style={{ color: '#333355' }}>2:35 PM</span>
                  </div>
                  <div className="flex justify-between items-center mt-0.5">
                    <span className="text-xs truncate" style={{ color: '#555577' }}>{conv.lastMessage}</span>
                    {conv.unread > 0 && <span className="ml-1 flex-shrink-0 text-xs font-bold w-4 h-4 rounded-full flex items-center justify-center" style={{ background: '#a855f7', color: 'white', fontSize: 9 }}>{conv.unread}</span>}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col" style={{ background: '#030308' }}>
        {/* Chat Header */}
        <div className="flex items-center justify-between px-6 py-4" style={{ borderBottom: '1px solid rgba(168,85,247,0.1)', background: 'rgba(8,8,18,0.8)', backdropFilter: 'blur(20px)' }}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full overflow-hidden" style={{ border: '2px solid rgba(168,85,247,0.4)' }}>
              <img src={mockUsers[1].avatar} alt="" className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-white">{mockUsers[1].username}</span>
                <CheckCircle2 size={13} style={{ color: '#3b82f6' }} />
              </div>
              <span className="text-xs" style={{ color: '#22c55e' }}>● Online</span>
            </div>
          </div>
          <div className="flex gap-2">
            {[Phone, Video, MoreHorizontal].map((Icon, i) => (
              <button key={i} className="p-2.5 rounded-xl hover:bg-white/5 transition-colors" style={{ color: '#555577' }}><Icon size={18} /></button>
            ))}
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          {messages.map(m => {
            const isMe = m.senderId === '1';
            return (
              <div key={m.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'} items-end gap-2`}>
                {!isMe && <div className="w-7 h-7 rounded-full overflow-hidden flex-shrink-0"><img src={mockUsers[1].avatar} alt="" className="w-full h-full" /></div>}
                <div className="max-w-xs">
                  <div className="px-4 py-2.5 rounded-2xl text-sm leading-relaxed" style={isMe
                    ? { background: 'linear-gradient(135deg, rgba(168,85,247,0.8), rgba(59,130,246,0.8))', color: 'white', borderBottomRightRadius: 4, boxShadow: '0 4px 15px rgba(168,85,247,0.3)' }
                    : { background: 'rgba(13,13,26,0.9)', color: '#c0c0dd', border: '1px solid rgba(168,85,247,0.15)', borderBottomLeftRadius: 4 }}>
                    {m.content}
                  </div>
                  <p className={`text-xs mt-1 ${isMe ? 'text-right' : ''}`} style={{ color: '#333355' }}>{m.time}</p>
                </div>
              </div>
            );
          })}
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full overflow-hidden"><img src={mockUsers[1].avatar} alt="" className="w-full h-full" /></div>
            <div className="px-4 py-2.5 rounded-2xl text-sm" style={{ background: 'rgba(13,13,26,0.9)', border: '1px solid rgba(168,85,247,0.15)', borderBottomLeftRadius: 4 }}>
              <div className="flex gap-1">
                {[0,1,2].map(i => <div key={i} className="w-1.5 h-1.5 rounded-full" style={{ background: '#a855f7', animation: `bounce 1.4s ${i*0.2}s infinite` }} />)}
              </div>
            </div>
          </div>
        </div>

        {/* Input */}
        <div className="p-4" style={{ borderTop: '1px solid rgba(168,85,247,0.1)' }}>
          <div className="flex items-center gap-3 px-4 py-3 rounded-2xl" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.2)' }}>
            <div className="flex gap-1">
              {[Smile, Image, Mic].map((Icon, i) => <button key={i} className="p-1.5 rounded-lg hover:bg-white/5 transition-colors" style={{ color: '#555577' }}><Icon size={16} /></button>)}
            </div>
            <input value={msg} onChange={e => setMsg(e.target.value)} placeholder="Type a message..." className="flex-1 bg-transparent outline-none text-sm" style={{ color: '#c0c0dd' }} />
            <button className="p-2 rounded-xl transition-all" style={{ background: msg ? 'linear-gradient(135deg, #a855f7, #3b82f6)' : 'rgba(168,85,247,0.2)', color: 'white', boxShadow: msg ? '0 0 12px rgba(168,85,247,0.4)' : 'none' }}>
              <Send size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
