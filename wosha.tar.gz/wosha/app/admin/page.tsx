import { Users, FileText, Video, MessageCircle, AlertTriangle, TrendingUp, DollarSign, Shield } from 'lucide-react';

const stats = [
  { label: 'Total Users', value: '2.4M', icon: Users, color: '#a855f7', change: '+12%' },
  { label: 'Posts Today', value: '48.2K', icon: FileText, color: '#3b82f6', change: '+8%' },
  { label: 'Videos', value: '12.8K', icon: Video, color: '#06b6d4', change: '+24%' },
  { label: 'Messages/hr', value: '890K', icon: MessageCircle, color: '#22c55e', change: '+5%' },
  { label: 'Reports', value: '1,247', icon: AlertTriangle, color: '#f59e0b', change: '-3%' },
  { label: 'Revenue', value: '$84.2K', icon: DollarSign, color: '#ec4899', change: '+18%' },
];

const recentUsers = [
  { id: '1', name: 'AkiraStorm', email: 'akira@wosha.io', status: 'active', role: 'creator', joined: '2024-01-15' },
  { id: '2', name: 'NeonSakura', email: 'sakura@wosha.io', status: 'active', role: 'creator', joined: '2024-02-01' },
  { id: '3', name: 'CyberWolf', email: 'wolf@wosha.io', status: 'suspended', role: 'user', joined: '2024-03-10' },
];

export default function AdminPage() {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <Shield size={28} style={{ color: '#a855f7' }} />
        <h1 className="text-3xl font-black text-white" style={{ fontFamily: 'Orbitron,monospace' }}>ADMIN</h1>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
        {stats.map(s => (
          <div key={s.label} className="p-4 rounded-2xl card-hover" style={{ background: 'rgba(13,13,26,0.8)', border: `1px solid ${s.color}22` }}>
            <div className="w-9 h-9 rounded-xl flex items-center justify-center mb-3" style={{ background: `${s.color}22` }}>
              <s.icon size={16} style={{ color: s.color }} />
            </div>
            <p className="text-xl font-black text-white">{s.value}</p>
            <p className="text-xs mb-1" style={{ color: '#555577' }}>{s.label}</p>
            <span className="text-xs font-semibold" style={{ color: s.change.startsWith('+') ? '#22c55e' : '#ef4444' }}>{s.change}</span>
          </div>
        ))}
      </div>

      {/* User Management Table */}
      <div className="rounded-2xl overflow-hidden" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.1)' }}>
        <div className="p-5 flex items-center justify-between" style={{ borderBottom: '1px solid rgba(168,85,247,0.1)' }}>
          <h2 className="font-bold text-white flex items-center gap-2"><Users size={16} style={{ color: '#a855f7' }} /> User Management</h2>
          <button className="px-3 py-1.5 rounded-lg text-xs font-semibold" style={{ background: 'rgba(168,85,247,0.2)', color: '#d8b4fe' }}>Export</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(168,85,247,0.08)' }}>
                {['User', 'Email', 'Role', 'Status', 'Joined', 'Actions'].map(h => (
                  <th key={h} className="px-5 py-3 text-left text-xs font-semibold" style={{ color: '#555577' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {recentUsers.map(u => (
                <tr key={u.id} className="hover:bg-white/2 transition-colors" style={{ borderBottom: '1px solid rgba(168,85,247,0.05)' }}>
                  <td className="px-5 py-4 text-sm font-semibold text-white">{u.name}</td>
                  <td className="px-5 py-4 text-sm" style={{ color: '#555577' }}>{u.email}</td>
                  <td className="px-5 py-4">
                    <span className="text-xs px-2 py-1 rounded-full capitalize" style={{ background: 'rgba(168,85,247,0.15)', color: '#a855f7' }}>{u.role}</span>
                  </td>
                  <td className="px-5 py-4">
                    <span className="text-xs px-2 py-1 rounded-full" style={u.status==='active' ? { background: 'rgba(34,197,94,0.15)', color: '#22c55e' } : { background: 'rgba(245,158,11,0.15)', color: '#f59e0b' }}>{u.status}</span>
                  </td>
                  <td className="px-5 py-4 text-xs" style={{ color: '#555577' }}>{u.joined}</td>
                  <td className="px-5 py-4">
                    <div className="flex gap-2">
                      <button className="text-xs px-2 py-1 rounded-lg" style={{ background: 'rgba(59,130,246,0.15)', color: '#60a5fa' }}>Edit</button>
                      <button className="text-xs px-2 py-1 rounded-lg" style={{ background: 'rgba(245,158,11,0.15)', color: '#f59e0b' }}>Suspend</button>
                      <button className="text-xs px-2 py-1 rounded-lg" style={{ background: 'rgba(239,68,68,0.15)', color: '#f87171' }}>Ban</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
