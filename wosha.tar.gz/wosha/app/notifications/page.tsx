import { Bell, Heart, MessageCircle, Users, Trophy, Zap } from 'lucide-react';

const notifs = [
  { type: 'like', text: 'AkiraStorm liked your post', time: '2m ago', icon: Heart, color: '#ef4444', read: false },
  { type: 'follow', text: 'NeonSakura started following you', time: '15m ago', icon: Users, color: '#a855f7', read: false },
  { type: 'comment', text: 'CyberWolf commented: "Insane work!"', time: '1h ago', icon: MessageCircle, color: '#3b82f6', read: false },
  { type: 'achievement', text: 'New achievement unlocked: Legend!', time: '3h ago', icon: Trophy, color: '#f59e0b', read: true },
  { type: 'xp', text: 'You gained 500 XP from your last post', time: '5h ago', icon: Zap, color: '#22c55e', read: true },
];

export default function NotificationsPage() {
  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-8">
        <Bell size={24} style={{ color: '#a855f7' }} />
        <h1 className="text-3xl font-black text-white" style={{ fontFamily: 'Orbitron,monospace' }}>ALERTS</h1>
        <span className="ml-auto px-3 py-1 rounded-full text-sm font-bold" style={{ background: 'rgba(168,85,247,0.2)', color: '#d8b4fe' }}>3 new</span>
      </div>
      <div className="space-y-2">
        {notifs.map((n, i) => (
          <div key={i} className="flex items-center gap-4 p-4 rounded-2xl transition-all" style={{ background: n.read ? 'rgba(13,13,26,0.6)' : 'rgba(13,13,26,0.95)', border: n.read ? '1px solid rgba(168,85,247,0.06)' : '1px solid rgba(168,85,247,0.2)', boxShadow: n.read ? 'none' : '0 0 10px rgba(168,85,247,0.08)' }}>
            <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${n.color}22` }}>
              <n.icon size={18} style={{ color: n.color }} />
            </div>
            <div className="flex-1">
              <p className="text-sm text-white">{n.text}</p>
              <p className="text-xs mt-0.5" style={{ color: '#555577' }}>{n.time}</p>
            </div>
            {!n.read && <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: '#a855f7', boxShadow: '0 0 6px #a855f7' }} />}
          </div>
        ))}
      </div>
    </div>
  );
}
