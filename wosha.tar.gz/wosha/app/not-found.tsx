import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen text-center p-6">
      <p style={{ fontFamily: 'Orbitron,monospace', fontSize: 120, fontWeight: 900, color: 'rgba(168,85,247,0.15)', lineHeight: 1 }}>404</p>
      <h1 className="text-3xl font-black text-white mt-4 mb-2">Page Not Found</h1>
      <p className="mb-8" style={{ color: '#555577' }}>This dimension doesn&apos;t exist in the WOSHA universe.</p>
      <Link href="/" className="px-6 py-3 rounded-xl font-semibold" style={{ background: 'linear-gradient(135deg,#a855f7,#3b82f6)', color: 'white' }}>Back to Feed</Link>
    </div>
  );
}
