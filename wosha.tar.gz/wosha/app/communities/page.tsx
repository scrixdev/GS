import { mockCommunities } from '@/lib/mockData';
import { Users, Lock, Globe, Hash, Mic } from 'lucide-react';

export default function CommunitiesPage() {
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-black" style={{ fontFamily: 'Orbitron,monospace', background: 'linear-gradient(135deg,#a855f7,#3b82f6)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>COMMUNITIES</h1>
        <button className="px-5 py-2.5 rounded-xl font-semibold text-sm" style={{ background: 'linear-gradient(135deg,#a855f7,#3b82f6)', color: 'white', boxShadow: '0 0 15px rgba(168,85,247,0.4)' }}>+ Create</button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {mockCommunities.map(c => (
          <div key={c.id} className="rounded-2xl overflow-hidden card-hover" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.1)' }}>
            <div className="h-24 relative" style={{ background: 'linear-gradient(135deg,#1a0033,#000d1a)' }}>
              <div className="absolute inset-0 flex items-center justify-center opacity-20">
                <span style={{ fontFamily: 'Orbitron,monospace', fontSize: 40, color: '#a855f7' }}>W</span>
              </div>
            </div>
            <div className="p-5 -mt-6">
              <div className="w-14 h-14 rounded-xl overflow-hidden mb-3" style={{ border: '3px solid #030308' }}>
                <img src={c.avatar} alt={c.name} className="w-full h-full object-cover bg-purple-900" />
              </div>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-bold text-white mb-1">{c.name}</h3>
                  <p className="text-xs mb-3 line-clamp-2" style={{ color: '#555577' }}>{c.description}</p>
                </div>
                {c.isPublic ? <Globe size={14} style={{ color: '#22c55e' }} /> : <Lock size={14} style={{ color: '#f59e0b' }} />}
              </div>
              <div className="flex flex-wrap gap-1.5 mb-4">
                {c.tags.map(tag => (
                  <span key={tag} className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(168,85,247,0.15)', color: '#a855f7' }}>{tag}</span>
                ))}
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 text-xs" style={{ color: '#555577' }}>
                  <Users size={12} /><span>{(c.members/1000).toFixed(1)}K members</span>
                </div>
                <button className="px-4 py-1.5 rounded-lg text-xs font-semibold" style={{ background: 'rgba(168,85,247,0.2)', color: '#d8b4fe', border: '1px solid rgba(168,85,247,0.3)' }}>Join</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
