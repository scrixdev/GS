export interface User {
  id: string;
  username: string;
  handle: string;
  avatar: string;
  bio: string;
  verified: boolean;
  followers: number;
  following: number;
  xp: number;
  level: number;
  badges: Badge[];
  isOnline?: boolean;
}

export interface Badge {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export interface Post {
  id: string;
  author: User;
  content: string;
  images?: string[];
  likes: number;
  comments: number;
  reposts: number;
  saves: number;
  liked: boolean;
  saved: boolean;
  hashtags: string[];
  createdAt: string;
  type: 'text' | 'image' | 'video' | 'carousel';
}

export interface Conversation {
  id: string;
  participants: User[];
  lastMessage: string;
  unread: number;
  pinned: boolean;
  isGroup: boolean;
  groupName?: string;
}

export interface Community {
  id: string;
  name: string;
  description: string;
  avatar: string;
  members: number;
  isPublic: boolean;
  tags: string[];
}

export interface MarketItem {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}
