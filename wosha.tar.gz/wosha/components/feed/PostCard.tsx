'use client';
import { useState } from 'react';
import { Heart, MessageCircle, Repeat2, Bookmark, Share2, MoreHorizontal, CheckCircle2 } from 'lucide-react';
import { Post } from '@/types';

function fmt(n: number) {
  if (n >= 1000000) return (n/1000000).toFixed(1) + 'M';
  if (n >= 1000) return (n/1000).toFixed(1) + 'K';
  return n.toString();
}

export default function PostCard({ post: initial }: { post: Post }) {
  const [post, setPost] = useState(initial);

  const toggleLike = () => setPost(p => ({ ...p, liked: !p.liked, likes: p.liked ? p.likes - 1 : p.likes + 1 }));
  const toggleSave = () => setPost(p => ({ ...p, saved: !p.saved, saves: p.saved ? p.saves - 1 : p.saves + 1 }));

  return (
    <div className="rounded-2xl card-hover cursor-pointer" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.1)', backdropFilter: 'blur(20px)' }}>
      <div className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-11 h-11 rounded-full overflow-hidden" style={{ border: '2px solid rgba(168,85,247,0.4)' }}>
                <img src={post.author.avatar} alt={post.author.username} className="w-full h-full object-cover" />
              </div>
              {post.author.isOnline && <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2" style={{ background: '#22c55e', borderColor: '#030308' }} />}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-white text-sm">{post.author.username}</span>
                {post.author.verified && <CheckCircle2 size={14} style={{ color: '#3b82f6' }} />}
                <span className="text-xs px-1.5 py-0.5 rounded-full" style={{ background: 'rgba(168,85,247,0.2)', color: '#a855f7' }}>Lv.{post.author.level}</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="text-xs" style={{ color: '#555577' }}>@{post.author.handle}</span>
                <span className="text-xs" style={{ color: '#333355' }}>·</span>
                <span className="text-xs" style={{ color: '#555577' }}>{post.createdAt}</span>
              </div>
            </div>
          </div>
          <button className="p-1.5 rounded-lg hover:bg-white/5 transition-colors" style={{ color: '#555577' }}>
            <MoreHorizontal size={16} />
          </button>
        </div>

        {/* Content */}
        <p className="text-sm leading-relaxed mb-3" style={{ color: '#c0c0dd' }}>{post.content}</p>

        {/* Hashtags */}
        <div className="flex flex-wrap gap-1.5 mb-4">
          {post.hashtags.map(tag => (
            <span key={tag} className="text-xs font-medium" style={{ color: '#6366f1' }}>{tag}</span>
          ))}
        </div>

        {/* Images */}
        {post.images && post.images.length > 0 && (
          <div className={`mb-4 gap-2 ${post.images.length > 1 ? 'grid grid-cols-2' : ''}`}>
            {post.images.map((img, i) => (
              <div key={i} className="rounded-xl overflow-hidden" style={{ maxHeight: post.images!.length > 1 ? 200 : 400 }}>
                <img src={img} alt="post" className="w-full h-full object-cover" />
              </div>
            ))}
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-between pt-3" style={{ borderTop: '1px solid rgba(168,85,247,0.08)' }}>
          <button onClick={toggleLike} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all duration-200 hover:bg-red-500/10 group">
            <Heart size={16} className={`transition-all ${post.liked ? 'fill-red-500 text-red-500 scale-110' : 'text-gray-500 group-hover:text-red-400'}`} />
            <span className={`text-xs font-medium ${post.liked ? 'text-red-400' : 'text-gray-500 group-hover:text-red-400'}`}>{fmt(post.likes)}</span>
          </button>
          <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all hover:bg-blue-500/10 group">
            <MessageCircle size={16} className="text-gray-500 group-hover:text-blue-400 transition-colors" />
            <span className="text-xs font-medium text-gray-500 group-hover:text-blue-400">{fmt(post.comments)}</span>
          </button>
          <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all hover:bg-green-500/10 group">
            <Repeat2 size={16} className="text-gray-500 group-hover:text-green-400 transition-colors" />
            <span className="text-xs font-medium text-gray-500 group-hover:text-green-400">{fmt(post.reposts)}</span>
          </button>
          <button onClick={toggleSave} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all hover:bg-purple-500/10 group">
            <Bookmark size={16} className={`transition-all ${post.saved ? 'fill-purple-500 text-purple-500' : 'text-gray-500 group-hover:text-purple-400'}`} />
            <span className={`text-xs font-medium ${post.saved ? 'text-purple-400' : 'text-gray-500 group-hover:text-purple-400'}`}>{fmt(post.saves)}</span>
          </button>
          <button className="p-1.5 rounded-lg hover:bg-white/5 transition-all group">
            <Share2 size={16} className="text-gray-500 group-hover:text-gray-300 transition-colors" />
          </button>
        </div>
      </div>
    </div>
  );
}
