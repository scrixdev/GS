'use client';
import { useState } from 'react';
import { Image, Video, Hash, AtSign, Smile, Send } from 'lucide-react';

export default function PostComposer() {
  const [text, setText] = useState('');
  return (
    <div className="rounded-2xl p-5" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.15)', backdropFilter: 'blur(20px)' }}>
      <div className="flex gap-3">
        <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0" style={{ border: '2px solid rgba(168,85,247,0.4)' }}>
          <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=me&backgroundColor=b6e3f4" alt="me" className="w-full h-full" />
        </div>
        <div className="flex-1">
          <textarea
            value={text}
            onChange={e => setText(e.target.value)}
            placeholder="What's happening in your world? 🌐"
            rows={3}
            className="w-full resize-none bg-transparent outline-none text-sm"
            style={{ color: '#e0e0ff', caretColor: '#a855f7' }}
          />
          <div className="flex items-center justify-between mt-3 pt-3" style={{ borderTop: '1px solid rgba(168,85,247,0.1)' }}>
            <div className="flex gap-1">
              {[Image, Video, Hash, AtSign, Smile].map((Icon, i) => (
                <button key={i} className="p-2 rounded-lg hover:bg-white/5 transition-colors" style={{ color: '#6644aa' }}>
                  <Icon size={16} />
                </button>
              ))}
            </div>
            <button disabled={!text.trim()} className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold transition-all duration-200 disabled:opacity-40"
              style={{ background: text.trim() ? 'linear-gradient(135deg, #a855f7, #3b82f6)' : 'rgba(168,85,247,0.2)', color: 'white', boxShadow: text.trim() ? '0 0 15px rgba(168,85,247,0.4)' : 'none' }}>
              <Send size={14} />
              Post
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
