'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, MessageCircle, Video, User, Users, ShoppingBag, LayoutDashboard, Zap, Bell, Search, Gamepad2 } from 'lucide-react';

const navItems = [
  { href: '/', icon: Home, label: 'Feed' },
  { href: '/explore', icon: Search, label: 'Explore' },
  { href: '/messages', icon: MessageCircle, label: 'Messages', badge: 3 },
  { href: '/videos', icon: Video, label: 'Videos' },
  { href: '/communities', icon: Users, label: 'Communities' },
  { href: '/gaming', icon: Gamepad2, label: 'Gaming' },
  { href: '/marketplace', icon: ShoppingBag, label: 'Market' },
  { href: '/profile', icon: User, label: 'Profile' },
  { href: '/notifications', icon: Bell, label: 'Alerts', badge: 12 },
  { href: '/admin', icon: LayoutDashboard, label: 'Admin' },
];

export default function Sidebar() {
  const pathname = usePathname();
  return (
    <aside className="fixed left-0 top-0 h-full w-64 z-50 flex flex-col" style={{ background: 'rgba(3,3,8,0.97)', borderRight: '1px solid rgba(168,85,247,0.12)' }}>
      <div className="p-6 pb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #a855f7, #3b82f6)', boxShadow: '0 0 20px rgba(168,85,247,0.5)' }}>
            <Zap size={20} className="text-white" />
          </div>
          <span className="text-2xl font-black tracking-wider" style={{ background: 'linear-gradient(135deg, #a855f7, #3b82f6, #06b6d4)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>WOSHA</span>
        </div>
      </div>
      <nav className="flex-1 px-3 space-y-0.5 overflow-y-auto">
        {navItems.map(({ href, icon: Icon, label, badge }) => {
          const active = pathname === href;
          return (
            <Link key={href} href={href} className="flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group relative"
              style={active ? { background: 'linear-gradient(135deg, rgba(168,85,247,0.15), rgba(59,130,246,0.15))', border: '1px solid rgba(168,85,247,0.25)', boxShadow: '0 0 15px rgba(168,85,247,0.1)' } : { border: '1px solid transparent' }}>
              <Icon size={20} style={active ? { color: '#a855f7' } : { color: '#555577' }} className="group-hover:text-gray-300 transition-colors" />
              <span className="font-medium transition-colors" style={active ? { color: '#d8b4fe' } : { color: '#555577' }}>{label}</span>
              {badge && <span className="ml-auto text-xs font-bold px-1.5 py-0.5 rounded-full" style={{ background: 'rgba(168,85,247,0.3)', color: '#d8b4fe', fontSize: '10px' }}>{badge}</span>}
              {active && <div className="ml-auto w-1.5 h-1.5 rounded-full" style={{ background: '#a855f7', boxShadow: '0 0 8px #a855f7' }} />}
            </Link>
          );
        })}
      </nav>
      <div className="p-3 m-3 rounded-xl" style={{ background: 'rgba(13,13,26,0.8)', border: '1px solid rgba(168,85,247,0.15)' }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full overflow-hidden" style={{ border: '2px solid rgba(168,85,247,0.5)' }}>
            <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=me&backgroundColor=b6e3f4" alt="me" className="w-full h-full object-cover" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-white truncate">AkiraStorm</p>
            <p className="text-xs truncate" style={{ color: '#a855f7' }}>Lv.87 • 98.4K XP</p>
          </div>
          <div className="w-2 h-2 rounded-full" style={{ background: '#22c55e', boxShadow: '0 0 6px #22c55e' }} />
        </div>
      </div>
    </aside>
  );
}
