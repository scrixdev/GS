import { User, Post, Conversation, Community, MarketItem } from '@/types';

export const mockUsers: User[] = [
  {
    id: '1', username: 'AkiraStorm', handle: 'akirastorm',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=akira&backgroundColor=b6e3f4',
    bio: 'Digital artist & gamer 🎮 | NFT creator | Level 99 grinder',
    verified: true, followers: 124500, following: 892, xp: 98400, level: 87,
    badges: [{ id: '1', name: 'OG Member', icon: '⚡', color: '#a855f7' }], isOnline: true,
  },
  {
    id: '2', username: 'NeonSakura', handle: 'neonsakura',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sakura&backgroundColor=ffdfbf',
    bio: 'Manhwa lover 📚 | Cosplayer | Community builder',
    verified: true, followers: 89200, following: 1200, xp: 67800, level: 62,
    badges: [{ id: '2', name: 'Creator', icon: '🎨', color: '#ec4899' }], isOnline: false,
  },
  {
    id: '3', username: 'CyberWolf', handle: 'cyberwolf',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=wolf&backgroundColor=c0aede',
    bio: 'Esports athlete | Team WOSHA captain | Streaming daily',
    verified: false, followers: 45000, following: 380, xp: 45200, level: 43,
    badges: [], isOnline: true,
  },
];

export const mockPosts: Post[] = [
  {
    id: '1', author: mockUsers[0], type: 'image',
    content: 'Just dropped my new digital art collection! 🎨✨ The future of creativity is here on WOSHA. Who else is building their digital empire?',
    images: ['https://picsum.photos/seed/wosha1/800/500'],
    likes: 4820, comments: 342, reposts: 891, saves: 1203, liked: false, saved: false,
    hashtags: ['#WOSHA', '#DigitalArt', '#Creator'], createdAt: '2h ago',
  },
  {
    id: '2', author: mockUsers[1], type: 'text',
    content: 'Chapter 47 of my original manhwa just dropped 📚🔥 The plot twist you never saw coming... WOSHA exclusive! Drop a 🔥 if you want chapter 48 faster',
    likes: 12400, comments: 1890, reposts: 3400, saves: 5600, liked: true, saved: true,
    hashtags: ['#Manhwa', '#OriginalContent', '#WOSHA'], createdAt: '5h ago',
  },
  {
    id: '3', author: mockUsers[2], type: 'carousel',
    content: 'TOURNAMENT RESULTS ARE IN 🏆 Team WOSHA takes first place! This win is for the entire community. We grind together, we win together 💜',
    images: ['https://picsum.photos/seed/gaming1/600/400', 'https://picsum.photos/seed/gaming2/600/400'],
    likes: 28900, comments: 4200, reposts: 8100, saves: 2300, liked: false, saved: false,
    hashtags: ['#Esports', '#Gaming', '#TeamWOSHA'], createdAt: '1d ago',
  },
];

export const mockConversations: Conversation[] = [
  { id: '1', participants: [mockUsers[0], mockUsers[1]], lastMessage: 'Check out my new drop! 🔥', unread: 3, pinned: true, isGroup: false },
  { id: '2', participants: [mockUsers[0], mockUsers[2]], lastMessage: 'GG on the tournament win!', unread: 0, pinned: false, isGroup: false },
  { id: '3', participants: mockUsers, lastMessage: 'Team meeting tomorrow at 8PM', unread: 12, pinned: true, isGroup: true, groupName: 'Team WOSHA 🏆' },
];

export const mockCommunities: Community[] = [
  { id: '1', name: 'WOSHA Creators Guild', description: 'The home of all digital creators on WOSHA', avatar: 'https://api.dicebear.com/7.x/shapes/svg?seed=guild', members: 45200, isPublic: true, tags: ['Art', 'Music', 'NFT'] },
  { id: '2', name: 'Esports Arena', description: 'Competitive gaming community for serious players', avatar: 'https://api.dicebear.com/7.x/shapes/svg?seed=esports', members: 128900, isPublic: true, tags: ['Gaming', 'Tournament'] },
  { id: '3', name: 'Manhwa Underground', description: 'Hidden gems and original manhwa content', avatar: 'https://api.dicebear.com/7.x/shapes/svg?seed=manhwa', members: 23400, isPublic: false, tags: ['Manhwa', 'Webtoon'] },
];

export const mockMarketItems: MarketItem[] = [
  { id: '1', name: 'Shadow Dragon Avatar', price: 500, image: 'https://api.dicebear.com/7.x/bottts/svg?seed=dragon', category: 'avatar', rarity: 'legendary' },
  { id: '2', name: 'Neon City Theme', price: 250, image: 'https://api.dicebear.com/7.x/shapes/svg?seed=neon', category: 'theme', rarity: 'epic' },
  { id: '3', name: 'Creator Badge', price: 100, image: 'https://api.dicebear.com/7.x/bottts/svg?seed=badge', category: 'badge', rarity: 'rare' },
  { id: '4', name: 'Galaxy Skin Pack', price: 750, image: 'https://api.dicebear.com/7.x/shapes/svg?seed=galaxy', category: 'skin', rarity: 'legendary' },
];
